import numpy as np
from enoppy.engineer import Engineer
from enoppy.utils.encoder import LabelEncoder

class SpeedReducerProblem(Engineer):

    name = "Speed Reducer Design Problem"

    def __init__(self, f_penalty=None):
        super().__init__()
        self._n_dims = 7
        self._n_objs = 1
        self._n_cons = 11
        self._bounds = [(2.6, 3.6), (0.7, 0.8), (17, 28.99), (7.3, 8.3), (7.3, 8.3), (2.9, 3.9), (5.0, 5.5)]
        self.check_penalty_func(f_penalty)

    def get_objs(self, x):
        f1 = 0.7854*x[0]*x[1]**2*(3.3333*x[2]**2 + 14.9334*x[2] - 43.0934) - 1.508*x[0]*(x[5]**2 + x[6]**2) +\
            7.4777*(x[5]**3 + x[6]**3) + 0.7854*(x[3]*x[5]**2 + x[4]*x[6]**2)
        return np.array([f1])

    def amend_position(self, x, lb=None, ub=None):
        x[2] = int(x[2])
        return x

    def get_cons(self, x):
        g1 = 27. / (x[0] * x[1] ** 2 * x[2]) - 1
        g2 = 397.5 / (x[0] * x[1] ** 2 * x[2] ** 2) - 1
        g3 = 1.93 * x[3] ** 2 / (x[1] * x[5] ** 4 * x[2]) - 1
        g4 = 1.93 * x[4] ** 2 / (x[1] * x[6] ** 4 * x[2]) - 1
        g5 = np.sqrt((745 * x[3] / (x[1] * x[2])) ** 2 + 16 * 10 ** 6) / (110 * x[5] ** 3) - 1
        g6 = np.sqrt((745 * x[4] / (x[1] * x[2])) ** 2 + 157.5 * 10 ** 6) / (85 * x[6] ** 3) - 1
        g7 = x[1] * x[2] / 40 - 1
        g8 = 5 * x[1] / x[0] - 1
        g9 = x[0] / (12. * x[1]) - 1
        g10 = (1.5 * x[5] + 1.9) / x[3] - 1
        g11 = (1.1 * x[6] + 1.9) / x[4] - 1
        return np.array([g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11])

    def evaluate(self, x):
        self.n_fe += 1
        self.check_solution(x)
        list_objs = self.get_objs(x)
        list_cons = self.get_cons(x)
        return self.f_penalty(list_objs, list_cons)


class Robot_Gripper(Engineer):
    """
    x = [x1, x2, x3, x4]

    Variables: the inner radius (R=x3), the thickness of the head (Th=x2),
        the length of the cylindrical section of the vessel (L=x4), and the thickness of the shell (Ts=x1)

    https://sci-hub.se/10.1115/1.2912596
    """

    name = "Robot_Gripper Design Problem"

    def __init__(self, f_penalty=None):
        super().__init__()
        self._n_dims = 7
        self._n_objs = 1
        self._n_cons = 6
        self._bounds = [(10, 150.), (10, 150.), (100., 200.), (0., 50.),(10, 150.),(100, 300.),(1, 3.14)]
        self.check_penalty_func(f_penalty)

    def get_objs(self, x):
        Ymin, Ymax, YG, Zmax = 50, 100, 150, 100
        # print(x)
        # 目标函数
        fhd1 = lambda z: np.real(self.F1(x, z, 2))
        fhd2 = lambda z: -np.real(self.F1(x, z, 2))
        from scipy.optimize import minimize_scalar
        fit1 = minimize_scalar(fhd1, bounds=(0, Zmax), method='bounded').fun
        fit2 = minimize_scalar(fhd2, bounds=(0, Zmax), method='bounded').fun
        f = -fit2 - fit1
        return np.array([f])

    def get_cons(self, x):
        # 约束
        a, b, c, e, ff, l, delta = x
        Ymin, Ymax, YG, Zmax = 50, 100, 150, 100
        g = np.zeros(7)
        g[0] = -Ymin + np.real(self.F1(x, Zmax, 1))
        g[1] = -np.real(self.F1(x, Zmax, 1))
        g[2] = Ymax - np.real(self.F1(x, 0, 1))
        g[3] = np.real(self.F1(x, 0, 1)) - YG
        g[4] = l ** 2 + e ** 2 - (a + b) ** 2
        g[5] = b ** 2 - (a - e) ** 2 - (l - Zmax) ** 2
        g[6] = Zmax - l
        return np.array(g)

    def evaluate(self, x):
        self.n_fe += 1
        self.check_solution(x)
        list_objs = self.get_objs(x)
        list_cons = self.get_cons(x)
        return self.f_penalty(list_objs, list_cons)

    def F1(self,x, z, flag):
        a, b, c, e, ff, l, delta = x
        P = 100

        g = np.sqrt(e ** 2 + (z - l) ** 2)
        phio = np.arctan(e / (l - z))
        alpha = np.arccos((a ** 2 + g ** 2 - b ** 2) / (2 * a * g)) + phio
        beta = np.arccos((b ** 2 + g ** 2 - a ** 2) / (2 * b * g)) - phio

        if flag == 1:
            y = 2 * (ff + e + c * np.sin(beta + delta))
            out = y
        elif flag == 2:
            Fk = P * b * np.sin(alpha + beta) / (2 * c * np.cos(alpha))
            out = Fk

        return out


class Step_cone_pulley(Engineer):


    name = "Step_cone_pulley Design Problem"

    def __init__(self, f_penalty=None):
        super().__init__()
        self._n_dims = 5
        self._n_objs = 1
        self._n_cons = 10
        self._bounds = [(0, 60.), (0, 60.),(0, 90.), (0, 90.),(0, 90.)  ]
        self.check_penalty_func(f_penalty)

    def get_objs(self, x):
        d1, d2, d3, d4, w = x
        d1 *= 1e-3
        d2 *= 1e-3
        d3 *= 1e-3
        d4 *= 1e-3
        w *= 1e-3
        N = 350
        N1, N2, N3, N4 = 750, 450, 250, 150
        rho, a, mu, s, t = 7200, 3, 0.35, 1.75 * 1e6, 8 * 1e-3
        f =rho * w * np.pi / 4 * (d1 ** 2 * (1 + (N1 / N) ** 2) + d2 ** 2 * (1 + (N2 / N) ** 2) +
                               d3 ** 2 * (1 + (N3 / N) ** 2) + d4 ** 2 * (1 + (N4 / N) ** 2))
        return np.array([f])

    def get_cons(self, x):
        # 约束
        d1, d2, d3, d4, w = x
        d1 *= 1e-3
        d2 *= 1e-3
        d3 *= 1e-3
        d4 *= 1e-3
        w *= 1e-3

        N = 350
        N1, N2, N3, N4 = 750, 450, 250, 150
        rho, a, mu, s, t = 7200, 3, 0.35, 1.75 * 1e6, 8 * 1e-3

        # 约束
        C1 = np.pi * d1 / 2 * (1 + N1 / N) + (N1 / N - 1) ** 2 * d1 ** 2 / (4 * a) + 2 * a
        C2 = np.pi * d2 / 2 * (1 + N2 / N) + (N2 / N - 1) ** 2 * d2 ** 2 / (4 * a) + 2 * a
        C3 = np.pi * d3 / 2 * (1 + N3 / N) + (N3 / N - 1) ** 2 * d3 ** 2 / (4 * a) + 2 * a
        C4 = np.pi * d4 / 2 * (1 + N4 / N) + (N4 / N - 1) ** 2 * d4 ** 2 / (4 * a) + 2 * a
        R1 = np.exp(mu * (np.pi - 2 * np.arcsin((N1 / N - 1) * d1 / (2 * a))))
        R2 = np.exp(mu * (np.pi - 2 * np.arcsin((N2 / N - 1) * d2 / (2 * a))))
        R3 = np.exp(mu * (np.pi - 2 * np.arcsin((N3 / N - 1) * d3 / (2 * a))))
        R4 = np.exp(mu * (np.pi - 2 * np.arcsin((N4 / N - 1) * d4 / (2 * a))))
        P1 = s * t * w * (1 - np.exp(-mu * (np.pi - 2 * np.arcsin((N1 / N - 1) * d1 / (2 * a))))) * np.pi * d1 * N1 / 60
        P2 = s * t * w * (1 - np.exp(-mu * (np.pi - 2 * np.arcsin((N2 / N - 1) * d2 / (2 * a))))) * np.pi * d2 * N2 / 60
        P3 = s * t * w * (1 - np.exp(-mu * (np.pi - 2 * np.arcsin((N3 / N - 1) * d3 / (2 * a))))) * np.pi * d3 * N3 / 60
        P4 = s * t * w * (1 - np.exp(-mu * (np.pi - 2 * np.arcsin((N4 / N - 1) * d4 / (2 * a))))) * np.pi * d4 * N4 / 60

        g = np.zeros(11)
        g[0] = -R1 + 2
        g[1] = -R2 + 2
        g[2] = -R3 + 2
        g[3] = -R4 + 2
        g[4] = -P1 + (0.75 * 745.6998)
        g[5] = -P2 + (0.75 * 745.6998)
        g[6] = -P3 + (0.75 * 745.6998)
        g[7] = -P4 + (0.75 * 745.6998)

        h = np.zeros(3)
        g[8] = abs(C1 - C2)
        g[9] = abs(C1 - C3)
        g[10] = abs(C1 - C4)
        return np.array(g)

    def evaluate(self, x):
        self.n_fe += 1
        self.check_solution(x)
        list_objs = self.get_objs(x)
        list_cons = self.get_cons(x)
        return self.f_penalty(list_objs, list_cons)


class gas(Engineer):

    name = "gas Design Problem"

    def __init__(self, f_penalty=None):
        super().__init__()
        self._n_dims = 4
        self._n_objs = 1
        self._n_cons = 1
        # [20, 1, 20, 0.1], [50, 10, 45, 60]
        self._bounds = [(20, 50.), (1, 10.),(20, 45.), (0.1, 60.)]
        self.check_penalty_func(f_penalty)

    def get_objs(self, x):
        x1, x2, x3, x4 = x

        # Objective function
        f = 8.61 * 10 ** 5 * x1 ** 0.5 * x2 * x3 ** (-1 * 2 / 3) * x4 ** (
                    -1 * 0.5) + 3.69 * 10 ** 4 * x3 + 7.72 * 10 ** 8 * x1 ** -1 * x2 ** 0.219 - 765.43 * 10 ** 6 * x1 ** -1
        return np.array([f])

    def get_cons(self, x):
        x1, x2, x3, x4 = x
        # Constraints
        g = x4 * x2 ** (-2) + x2 ** (-2) - 1

        return np.array([g])

    def evaluate(self, x):
        self.n_fe += 1
        self.check_solution(x)
        list_objs = self.get_objs(x)
        list_cons = self.get_cons(x)
        return self.f_penalty(list_objs, list_cons)

class PressureVesselProblem(Engineer):

    name = "Pressure Vessel Design Problem"

    def __init__(self, f_penalty=None):
        super().__init__()
        self._n_dims = 4
        self._n_objs = 1
        self._n_cons = 4
        self._bounds = [(0., 99.), (0., 99.), (10., 200.), (10., 200.)]
        self.check_penalty_func(f_penalty)

    def get_objs(self, x):
        f1 = 0.6224 * x[2] * x[0] * x[3] + 1.7781 * x[2] ** 2 * x[1] + 3.1611 * x[0] ** 2 * x[3] + 19.8621 * x[2] * x[0] ** 2
        return np.array([f1])

    def get_cons(self, x):
        g1 = -x[0] + 0.0193 * x[2]
        g2 = -x[2] + 0.00954 * x[2]
        g3 = -np.pi * x[1] ** 2 * x[3] - 4. / 3 * np.pi * x[2] ** 3 + 750 * 1728
        g4 = -240 + x[3]
        return np.array([g1, g2, g3, g4])

    def evaluate(self, x):
        self.n_fe += 1
        self.check_solution(x)
        list_objs = self.get_objs(x)
        list_cons = self.get_cons(x)
        return self.f_penalty(list_objs, list_cons)


class ThreeBarTrussProblem(Engineer):
    name = "Three Bar Truss Design Problem"

    def __init__(self, f_penalty=None):
        super().__init__()
        self._n_dims = 2
        self._n_objs = 1
        self._n_cons = 3
        self._bounds = [(0., 1.0), (0., 1.)]
        self.L = 100
        self.P = 2
        self.xichma = 2
        self.check_penalty_func(f_penalty)

    def get_objs(self, x):
        f1 = (2*np.sqrt(2)*x[0] + x[1]) * self.L
        return np.array([f1])

    def get_cons(self, x):
        g1 = (np.sqrt(2) * x[0] + x[1]) / (np.sqrt(2) * x[0] ** 2 + 2 * x[0] * x[1]) * self.P - self.xichma
        g2 = x[1] * self.P / (np.sqrt(x[0] ** 2 + 2 * x[0] * x[1])) - self.xichma
        g3 = self.P / (np.sqrt(2) * x[1] + x[0]) - self.xichma
        return np.array([g1, g2, g3])

    def evaluate(self, x):
        self.n_fe += 1
        self.check_solution(x)
        list_objs = self.get_objs(x)
        list_cons = self.get_cons(x)
        return self.f_penalty(list_objs, list_cons)

RG=Robot_Gripper
SCP=Step_cone_pulley
gas=gas
PVP = PressureVesselProblem
SRD = SpeedReducerProblem
TBTD = ThreeBarTrussProblem
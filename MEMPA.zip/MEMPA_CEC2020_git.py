import mealpy
from mealpy import FloatVar
import os
from opfunu.cec_based.cec2020 import *
import numpy as np
import warnings

from MEMPA import OriginalMEMPA

warnings.filterwarnings("ignore")
def main(Dim):
    trials =10
    PopSize =30
    MaxIter =1000
    CEC2020 = [F12020(Dim), F22020(Dim), F32020(Dim), F42020(Dim), F52020(Dim), F62020(Dim),
               F72020(Dim), F82020(Dim), F92020(Dim), F102020(Dim)]

    for i in range(len(CEC2020)):
        problem_dict = {
            "bounds": FloatVar(lb=[-100] * Dim, ub=[100] * Dim),
            "obj_func": CEC2020[i].evaluate,
            "lb": [-100] * Dim,
            "ub": [100] * Dim,
            "minmax": "min",
            "log_to": None
        }

        All_Trial_Best = []
        for j in range(trials):
            np.random.seed(1996 + 20 * j)
            from MEMPAgit import OriginalMEMPA
            solver = OriginalMEMPA(epoch=MaxIter, pop_size=PopSize)
            solver.solve(problem_dict)
            All_Trial_Best.append(solver.history.list_global_best_fit)
        np.savetxt("./MEMPA_Data/CEC2020/F" + str(i + 1) + "_" + str(Dim) + "D.csv", All_Trial_Best, delimiter=",")


if __name__ == "__main__":
    if os.path.exists('./MEMPA_Data/CEC2020') == False:
        os.makedirs('./MEMPA_Data/CEC2020')
    Dims = [10]
    for Dim in Dims:
        main(Dim)

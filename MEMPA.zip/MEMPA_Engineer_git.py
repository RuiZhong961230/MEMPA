import os
import mealpy
import numpy as np
import warnings
from mealpy import FloatVar
from MEMPAgit import OriginalMEMPA
from MyENgit import  *
warnings.filterwarnings("ignore")


def main():
    trials = 30
    PopSize = 30
    MaxIter = 1000

    Probs = [PVP(),SRD(),TBTD(),RG(),SCP(),gas()]

    Names = ["PVP", "SRD", "TBTD", "RG", "SCP", "gas" ]

    for i in range(len(Probs)):
        problem_dict = {
            "bounds": FloatVar(lb=np.array(Probs[i].bounds)[:, 0], ub=np.array(Probs[i].bounds)[:, 1]),
            "obj_func": Probs[i].evaluate,
            "minmax": "min",
            "log_to": None
        }
        All_Trial_Best = []
        for j in range(trials):
            solver = OriginalMEMPA(epoch=MaxIter, pop_size=PopSize)
            solver.solve(problem_dict)
            All_Trial_Best.append(solver.history.list_global_best_fit)
        if os.path.exists('./MEMPA_Data/Engineer'+ Names[i] + ".csv") == False:
            with open("./MEMPA_Data/Engineer/" + Names[i] + ".csv", "w") as csv_file:
                pass
        np.savetxt("./MEMPA_Data/Engineer/" + Names[i] + ".csv", All_Trial_Best, delimiter=",")


if __name__ == "__main__":
    if os.path.exists('./MEMPA_Data/Engineer') == False:
        os.makedirs('./MEMPA_Data/Engineer')
    main()
